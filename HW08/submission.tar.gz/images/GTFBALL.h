/*
 * Exported with nin10kit v1.8
 * Invocation command was nin10kit --mode=3 --resize=240x160 GTFBALL GTFBALL.png 
 * Time-stamp: Sunday 11/07/2021, 16:45:16
 * 
 * Image Information
 * -----------------
 * GTFBALL.png 240@160
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef GTFBALL_H
#define GTFBALL_H

extern const unsigned short GTFBALL[38400];
#define GTFBALL_SIZE 76800
#define GTFBALL_LENGTH 38400
#define GTFBALL_WIDTH 240
#define GTFBALL_HEIGHT 160

#endif

