/*
 * Exported with nin10kit v1.8
 * Invocation command was nin10kit --mode=3 --resize=240x160 Losing Losing.jpg 
 * Time-stamp: Sunday 11/07/2021, 17:00:50
 * 
 * Image Information
 * -----------------
 * Losing.jpg 240@160
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef LOSING_H
#define LOSING_H

extern const unsigned short Losing[38400];
#define LOSING_SIZE 76800
#define LOSING_LENGTH 38400
#define LOSING_WIDTH 240
#define LOSING_HEIGHT 160

#endif

