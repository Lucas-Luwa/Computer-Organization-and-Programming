/*
 * Exported with nin10kit v1.8
 * Invocation command was nin10kit --mode=3 --resize=240x160 red red.jpg 
 * Time-stamp: Sunday 11/07/2021, 17:01:05
 * 
 * Image Information
 * -----------------
 * red.jpg 240@160
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef RED_H
#define RED_H

extern const unsigned short red[38400];
#define RED_SIZE 76800
#define RED_LENGTH 38400
#define RED_WIDTH 240
#define RED_HEIGHT 160

#endif

