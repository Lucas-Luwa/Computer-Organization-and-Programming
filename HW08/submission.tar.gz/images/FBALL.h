/*
 * Exported with nin10kit v1.8
 * Invocation command was nin10kit --mode=3 --resize=240x160 FBALL FBALL.png 
 * Time-stamp: Sunday 11/07/2021, 17:00:23
 * 
 * Image Information
 * -----------------
 * FBALL.png 240@160
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef FBALL_H
#define FBALL_H

extern const unsigned short FBALL[38400];
#define FBALL_SIZE 76800
#define FBALL_LENGTH 38400
#define FBALL_WIDTH 240
#define FBALL_HEIGHT 160

#endif

