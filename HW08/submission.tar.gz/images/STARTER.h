/*
 * Exported with nin10kit v1.8
 * Invocation command was nin10kit --mode=3 --resize=240x160 STARTER STARTER.png 
 * Time-stamp: Sunday 11/07/2021, 17:26:11
 * 
 * Image Information
 * -----------------
 * STARTER.png 240@160
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef STARTER_H
#define STARTER_H

extern const unsigned short STARTER[38400];
#define STARTER_SIZE 76800
#define STARTER_LENGTH 38400
#define STARTER_WIDTH 240
#define STARTER_HEIGHT 160

#endif

