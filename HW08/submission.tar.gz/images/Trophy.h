/*
 * Exported with nin10kit v1.8
 * Invocation command was nin10kit --mode=3 --resize=240x160 Trophy Trophy.png 
 * Time-stamp: Monday 11/08/2021, 04:09:02
 * 
 * Image Information
 * -----------------
 * Trophy.png 240@160
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef TROPHY_H
#define TROPHY_H

extern const unsigned short Trophy[38400];
#define TROPHY_SIZE 76800
#define TROPHY_LENGTH 38400
#define TROPHY_WIDTH 240
#define TROPHY_HEIGHT 160

#endif

