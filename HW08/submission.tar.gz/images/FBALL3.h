/*
 * Exported with nin10kit v1.8
 * Invocation command was nin10kit --mode=3 --resize=20x15 FBALL3 FBALL3.jpg 
 * Time-stamp: Monday 11/08/2021, 03:57:05
 * 
 * Image Information
 * -----------------
 * FBALL3.jpg 20@15
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef FBALL3_H
#define FBALL3_H

extern const unsigned short FBALL3[300];
#define FBALL3_SIZE 600
#define FBALL3_LENGTH 300
#define FBALL3_WIDTH 20
#define FBALL3_HEIGHT 15

#endif

